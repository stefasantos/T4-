def ip_para_binario(ip_str):
    octetos = [int(x) for x in ip_str.split('.')]
    if len(octetos) != 4:
        raise ValueError("IP deve conter 4 octetos!")
    for octeto in octetos:
        if not (0 <= octeto <= 255):
            raise ValueError(f"Octeto fora do intervalo (0-255): {octeto}")
    return (octetos[0] << 24) | (octetos[1] << 16) | (octetos[2] << 8) | octetos[3]

def binario_para_ip(ip_int):
    return f"{(ip_int >> 24) & 255}.{(ip_int >> 16) & 255}.{(ip_int >> 8) & 255}.{ip_int & 255}"

def calcular_rede(entrada):
    ip_str, cidr_str = entrada.split('/')
    cidr = int(cidr_str)
    if not (0 <= cidr <= 32):
        raise ValueError("CIDR deve estar entre 0 e 32!")
    ip_bin = ip_para_binario(ip_str)
    mascara_bin = (0xffffffff << (32 - cidr)) & 0xffffffff
    rede_bin = ip_bin & mascara_bin
    inverso_mascara = (~mascara_bin) & 0xffffffff
    broadcast_bin = rede_bin | inverso_mascara
    if cidr == 32:
        primeiro_host_bin = ultimo_host_bin = ip_bin
    elif cidr == 31:
        primeiro_host_bin = rede_bin
        ultimo_host_bin = broadcast_bin
    else:
        primeiro_host_bin = rede_bin + 1
        ultimo_host_bin = broadcast_bin - 1
    return {
        "rede": binario_para_ip(rede_bin),
        "broadcast": binario_para_ip(broadcast_bin),
        "primeiro_host": binario_para_ip(primeiro_host_bin),
        "ultimo_host": binario_para_ip(ultimo_host_bin),
        "mascara": binario_para_ip(mascara_bin)
    }

def imprimir_resultado(res):
    print("\n" + "=" * 30)
    print(f"Endereço de Rede:     {res['rede']}")
    print(f"Máscara:              {res['mascara']}")
    print(f"Endereço de Broadcast:{res['broadcast']}")
    print(f"Primeiro Host:        {res['primeiro_host']}")
    print(f"Último Host:          {res['ultimo_host']}")
    print("=" * 30 + "\n")

entrada_usuario = input("Digite o IP e Máscara (ex: 192.168.248.250/24): ")
resultado = calcular_rede(entrada_usuario)
imprimir_resultado(resultado)
